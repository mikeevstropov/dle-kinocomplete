<?php

namespace Kinocomplete\User;

class User
{
  /**
   * @var string
   */
  public $id = '';

  /**
   * @var string
   */
  public $name = '';

  /**
   * @var string
   */
  public $email = '';
}