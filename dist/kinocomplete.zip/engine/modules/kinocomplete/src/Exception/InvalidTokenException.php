<?php

namespace Kinocomplete\Exception;

class InvalidTokenException extends \Exception {}