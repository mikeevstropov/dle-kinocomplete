<?php

namespace Kinocomplete\Exception;

class TooLargeResponseException extends \Exception {}