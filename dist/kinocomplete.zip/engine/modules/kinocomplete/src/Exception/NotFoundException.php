<?php

namespace Kinocomplete\Exception;

class NotFoundException extends \Exception {}