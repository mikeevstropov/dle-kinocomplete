<?php

namespace Kinocomplete\Exception;

class FileSystemPermissionException extends \Exception {}