<?php

namespace Kinocomplete\Exception;

class ParsingException extends \Exception {}
