<?php

namespace Kinocomplete\Exception;

class FeedsHostNotFoundException extends \Exception {}
