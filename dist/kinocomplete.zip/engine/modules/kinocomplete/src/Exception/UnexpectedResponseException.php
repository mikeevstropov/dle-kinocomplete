<?php

namespace Kinocomplete\Exception;

class UnexpectedResponseException extends \Exception {}