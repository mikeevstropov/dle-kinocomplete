<?php

namespace Kinocomplete\Exception;

class HostNotFoundException extends \Exception {}