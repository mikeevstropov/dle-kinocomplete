<?php

namespace Kinocomplete\Exception;

class TokenNotFoundException extends \Exception {}