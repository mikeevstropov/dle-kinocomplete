<?php

namespace Kinocomplete\Exception;

class BasePathNotFoundException extends \Exception {}