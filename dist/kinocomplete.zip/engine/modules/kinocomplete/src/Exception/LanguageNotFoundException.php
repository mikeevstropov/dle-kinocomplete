<?php

namespace Kinocomplete\Exception;

class LanguageNotFoundException extends \Exception {}