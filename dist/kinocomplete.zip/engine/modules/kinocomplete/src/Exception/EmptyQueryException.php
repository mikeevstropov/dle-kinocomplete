<?php

namespace Kinocomplete\Exception;

class EmptyQueryException extends \Exception {}