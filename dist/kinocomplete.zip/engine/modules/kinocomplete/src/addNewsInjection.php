<?php

$js_array[] = "/engine/modules/kinocomplete/web/dist/injections/add-news.min.js";