<?php

$js_array[] = "/engine/modules/kinocomplete/web/dist/injections/edit-news.min.js";