<?php

define('DEFAULT_MODE', 0);

define('LOWER_CASE', 1);
define('UPPER_CASE', 2);
define('CAPITAL_CASE', 3);