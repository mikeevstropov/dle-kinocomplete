/* jQuery Chosen */
$('.chosen-select').chosen({
  'no_results_text': 'Нет доступных опций.'
});