import SourceComponent from './source-component';
import SourceView from './source-view';

export default {
  SourceComponent,
  SourceView,
};
