import MoonwalkComponent from './moonwalk-component';
import MoonwalkView from './moonwalk-view';

export default {
  MoonwalkComponent,
  MoonwalkView,
};
