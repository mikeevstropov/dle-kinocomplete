import '../src/extensions/object';
import '../src/extensions/array';

jest.setTimeout(20000);
