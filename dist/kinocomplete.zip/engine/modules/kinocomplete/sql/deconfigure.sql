DROP TABLE IF EXISTS `{{database_prefix}}{{database_configuration_table}}`;
DROP TABLE IF EXISTS `{{database_prefix}}{{database_feed_posts_table}}`;